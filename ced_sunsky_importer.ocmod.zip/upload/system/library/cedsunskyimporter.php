<?php

//require_once DIR_SYSTEM . "library/ced1688importer/Generate.php";

class CedSunskyImporter
{
    private static $instance;
    private $db;
    private $session;
    private $config;
    private $currency;
    private $request;
    private $weight;
    protected $endpointUrl = '';
    protected $key = '';
    protected $secret = '';

    /**
     * @param  object $registry Registry Object
     */
    public function __construct($registry)
    {
        $this->db = $registry->get('db');
        $this->session = $registry->get('session');
        $this->config = $registry->get('config');
        $this->currency = $registry->get('currency');
        $this->request = $registry->get('request');
        $this->weight = $registry->get('weight');
    }

    /**
     * @param  object $registry Registry Object
     */
    public static function getInstance($registry)
    {
        if (is_null(static::$instance)) {
            static::$instance = new static($registry);
        }

        return static::$instance;
    }

    public function _init()
    {
      $this->endpointUrl = "http://www.sunsky-api.com/openapi/";
      $this->key = $this->config->get('ced_sunsky_importer_key');
      $this->secret = $this->config->get('ced_sunsky_importer_secret');
    }

    public function isEnabled()
    {
        $flag = false;
        if ($this->config->get('ced_sunsky_importer_status')) {
            $flag = true;
            $this->_init();
        }
        return $flag;
    }

    public function isInstalled()
    {
        if ($this->db->query("SHOW TABLES LIKE '" . DB_PREFIX . "ced_sunsky_importer_settings'")->num_rows) {
            return true;
        } else {
            return false;
        }
    }

    public function install()
    {
      $cedsunsky_importer_product_attribute_combination = "CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "ced_sunsky_importer_product_attribute_combination` (
        `combination_id` int(10) NOT NULL AUTO_INCREMENT COMMENT 'ID',
        `product_id` int(11) NOT NULL,
        `sku_id` text COLLATE utf8_unicode_ci NOT NULL,
        `combination` text COLLATE utf8_unicode_ci NOT NULL,
        `options` text COLLATE utf8_unicode_ci NOT NULL,
        `cedsunsky_item_id` bigint(20) NOT NULL,
        `images` longtext COLLATE utf8_unicode_ci NOT NULL,
        `response_data` longtext COLLATE utf8_unicode_ci NOT NULL,
        PRIMARY KEY (`combination_id`)
      );";

      $created = $this->db->query($cedsunsky_importer_product_attribute_combination);
      if ($created)
        $this->log("ced_sunsky_importer_product_attribute_combination table created", 6, true);

        //Order
        $order = $this->db->query("
                CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "ced_sunsky_importer_order` (
                  `id` int(11) NOT NULL AUTO_INCREMENT,
                  `opencart_order_id` int(11) NULL,
                  `sunsky_order_id` text NULL,
                  `order_data` longtext NULL,
                  `order_place_date` datetime NULL,
                  `sunsky_status` text NULL,
                  PRIMARY KEY  (`id`)
                ) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
            ");

        if ($order)
            $this->log("ced_sunsky_importer_order table created", 6, true);

        //Order Error
        $order_error = $this->db->query("
                CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "ced_sunsky_importer_order_error` (
                  `id` int(11) NOT NULL AUTO_INCREMENT,
                  `merchant_sku` text NULL,
                  `ced_sunsky_order_id` text NULL,
                  `order_data` longtext NULL,
                  `reason` text NULL,
                  `cancel_qty` int(10),
                  PRIMARY KEY  (`id`)
                ) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
            ");

        if ($order_error)
            $this->log("ced_sunsky_importer_order_error table created", 6, true);

        //Country
        $country = $this->db->query("
                CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "ced_sunsky_importer_country` (
                  `country_primary_id` int(11) NOT NULL AUTO_INCREMENT,
                  `id` int(11) NOT NULL,
                  `name` text NOT NULL,
                  `code` text NOT NULL,
                  `shipToState` tinyint(1) NOT NULL,
                  PRIMARY KEY  (`country_primary_id`)
                ) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
            ");

        if ($country)
            $this->log("ced_sunsky_importer_country table created", 6, true);

        // State
        $state = $this->db->query("
                CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "ced_sunsky_importer_state` (
                  `id` int(11) NOT NULL AUTO_INCREMENT,
                  `country_id` int(11) NOT NULL,
                  `name` text NOT NULL,
                  `code` text NOT NULL,
                  PRIMARY KEY  (`id`)
                ) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
            ");

        if ($state)
            $this->log("ced_sunsky_importer_state table created", 6, true);
    }

    public function log($data, $step = 6, $force_log = false)
    {
        if ($force_log) {
            $backtrace = debug_backtrace();
            $log = new Log('cedsunskyimporter.log');
            if (is_array($data))
                $data = json_encode($data);
            if (isset($backtrace[$step]) && isset($backtrace[$step]['class']) && isset($backtrace[$step]['class'])) {
                $log->write('(' . $backtrace[$step]['class'] . '::' . $backtrace[$step]['function'] . ') - ' . $data);
            } else {
                $log->write($data);
            }
        }
    }

    public function sign($parameters, $secret)
    {
        $signature = '';
        ksort($parameters);
        foreach($parameters as $key=>$value){
            $signature .= $value;
        }
        $signature = $signature . '@' . $secret;
        $signature = md5($signature);
        return $signature;
    }

    public function getProductData($url, $parameters)
    {
        $response = array();
        $this->_init();
        $apiUrl = $this->endpointUrl . $url;
        $parameters['key'] = $this->key;
        $signature = $this->sign($parameters, $this->secret);
        $parameters['signature'] = $signature;
        $postdata = http_build_query($parameters);
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $apiUrl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        $output = curl_exec($ch);
        curl_close($ch);

        if(isset($output) && !empty($output))
        {
            $output = json_decode($output, true);
            
            if(isset($output['result']) && ($output['result'] == 'success'))
            {
                if((isset($output['data']['result']) && count($output['data']['result'])) || (isset($output['data']) && is_array($output['data'])))
                {
                    $response['success'] = true;
                    $response['message'] = $output['data'];
                }
            } else {
                $response['success'] = false;
                if(isset($output['messages']))
                    $response['message'] = implode(',', $output['messages']);
                else
                    $response['message'] = 'No result found!';
            }
        }
        return $response;
    }

    public function download($url, $parameters, $path)
    {
        $response = array();
        $this->_init();
        $apiUrl = $this->endpointUrl . $url;
        $parameters['key'] = $this->key;
        $signature = $this->sign($parameters, $this->secret);
        $parameters['signature'] = $signature;
        $postdata = http_build_query($parameters);
        $fp = fopen($path, "w");
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $apiUrl);
        curl_setopt($ch, CURLOPT_FILE, $fp);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 20);
        curl_setopt($ch, CURLOPT_TIMEOUT, 50);
        $output = curl_exec($ch);
        file_put_contents($path, $output);
        //$file_unzip_path = DIR_IMAGE . 'catalog/demo/';
        //unzip($file_unzip_path, $path);
        curl_close($ch);
        fclose($fp);
        if(!empty($output))
        {
            $response['success'] = true;
            $response['message'] = 'Image(s) fetched successfully';
        } else {
            $response['success'] = false;
            $response['message'] = 'Failed to fetch Image(s) file';
        }
        return $response;
    }

    public function prepareProductData($filter_data, $product_data = array(), $category_id = '', $manufacturer_id = '')
    {
        $response = array();
        if(isset($product_data) && is_array($product_data))
        {
            try{
                if (isset($filter_data) && !empty($filter_data)) 
                {
                    $date_available = $this->config->get('ced_sunsky_importer_available_date');
                    $tax_class_id = $this->config->get('ced_sunsky_importer_tax_class_id');
                    $length_class_id = $this->config->get('ced_sunsky_importer_length_class_id');
                    $weight_class_id = $this->config->get('ced_sunsky_importer_weight_class_id');
                    $category = $this->config->get('ced_sunsky_importer_product_category');
                    $store = $this->config->get('ced_sunsky_importer_product_store');
                    // $data['status'] = $this->config->get('ced_1688_importer_status');
                    $data = array();
                    if ($this->config->get('ced_sunsky_importer_field_mapping')) {
                        foreach ($this->config->get('ced_sunsky_importer_field_mapping') as $key => $value) {
                            $data[$key] = $value;
                        }
                    }
                }
                if(empty($date_available))
                  $date_available = date('Y-m-d h:i:s a');
                if(empty($tax_class_id))
                  $tax_class_id = '9';
                if(empty($length_class_id))
                  $length_class_id = '1';
                if(empty($weight_class_id))
                  $weight_class_id = '1';
                $language_id = $this->config->get('ced_sunsky_importer_language');
                //$languages = $this->getLanguages();
                $store_id = $this->config->get('config_store_id');
                $product_ids = [];
                $existing_product_ids = [];

                foreach($product_data as $key => $product)
                {
                   //echo '<pre>'; print_r($product); die;
                    $existingProduct = $this->db->query("SELECT * FROM `" . DB_PREFIX . "product` WHERE `sku` = '" . $this->db->escape($product['itemNo']) . "' ");
                    if ($existingProduct->num_rows == 0) 
                    {
                        $url = 'product!getImages.do';
                        $params = array(
                            'itemNo'    => $product['itemNo'],
                            'size'      => '500',
                            //'watermark' => 'mysite.com'
                            );
                        $dir_path = DIR_IMAGE . 'ced_sunsky_importer/';
                        if(!is_dir($dir_path))
                        {
                            mkdir($dir_path, 0777);
                        }
                        $path = $dir_path . $product['itemNo'] .'.zip';
                        $ImageData = $this->download($url, $params, $path);
                        //echo '<pre>'; print_r($ImageData); die;
                        $model = $product['id'];
                        $sku = $product['itemNo'];
                        if($product['stock'] == '0')
                        {
                            $quantity = $product['packQty'];
                        } else {
                            $quantity = $product['stock'];
                        }
                        
                        $status = $product['status'];
                        if(isset($product['status']) && ($product['status'] == '1')){
                            $stock_status_id = '7';
                        } else {
                            $stock_status_id = '5';
                        }

                        if(isset($product['orgPrice']) && !empty($product['orgPrice']))
                        {
                            $price = $product['orgPrice'];
                            $specialPrice = $product['price'];
                        } else {
                            $price = $product['price'];
                        }

                        $this->db->query("INSERT INTO `" . DB_PREFIX . "product` SET 
                          model = '" . $this->db->escape($model) . "', 
                          sku = '". $this->db->escape($sku) ."',
                          quantity = '" . (int)$quantity . "', 
                          date_available = '". $date_available ."', 
                          manufacturer_id = '" . (int)$manufacturer_id . "', 
                          price = '" . (float) $price . "', 
                          stock_status_id = '". (int) $stock_status_id ."', 
                          length_class_id = '" . (int)$length_class_id . "', 
                          weight_class_id = '". (int) $weight_class_id ."',
                          status = '". (int) $product['status'] ."', 
                          tax_class_id = '" . (int)$tax_class_id . "', 
                          sort_order = '1',
                          image = '". html_entity_decode($image) ."',
                          weight = '". $product['packWeight'] ."',
                          length = '". $product['packLength'] ."',
                          height = '". $product['packHeight'] ."',
                          width = '". $product['packWidth'] ."',
                          date_added = NOW()");

                        $product_id = $this->db->getLastId();

                        $category_id = !empty($category_id) ? $category_id : $product['categoryId'];
                
                        if (!empty($category_id)) {
                            $this->db->query("INSERT INTO " . DB_PREFIX . "product_to_category SET product_id = '" . (int)$product_id . "', category_id = '" . (int)$category_id . "'");
                        } elseif(is_array($category) && !empty($category)) {
                            foreach($category as $key => $category_id)
                            {
                              $this->db->query("INSERT INTO " . DB_PREFIX . "product_to_category SET product_id = '" . (int)$product_id . "', category_id = '" . (int)$category_id . "'");
                            }
                        }

                        if(is_array($store) && !empty($store)) {
                          foreach($store as $key => $store_id)
                          {
                            $this->db->query("INSERT INTO " . DB_PREFIX . "product_to_store SET product_id = '" . (int)$product_id . "', store_id = '" . (int)$store_id . "'");
                          }
                        } elseif (!empty($store_id)) {
                          $this->db->query("INSERT INTO " . DB_PREFIX . "product_to_store SET product_id = '" . (int)$product_id . "', store_id = '" . (int)$store_id . "' ");
                        }

                        $this->db->query("INSERT INTO `" . DB_PREFIX . "product_description` SET 
                            product_id = '" . (int)$product_id . "', 
                            language_id = '" . (int)$language_id . "',
                            name = '" . $this->db->escape($product['name']) . "', 
                            description = '" . $this->db->escape($product['description']) . "', 
                            tag = '', 
                            meta_description = '". $this->db->escape($product['name']) ."', 
                            meta_keyword = '', 
                            meta_title = '" . $this->db->escape($product['name']) . "' 
                            ");

                        if(isset($product['priceList']) && !empty($product['priceList']) && is_array($product['priceList']))
                        {
                            $priority = '1';
                            foreach($product['priceList'] as $key => $quantityRange)
                            {
                                $this->db->query("INSERT INTO `". DB_PREFIX ."product_discount` SET 
                                  `product_id` = '". (int) $product_id ."', 
                                  `customer_group_id` = '". (int) $this->config->get('config_customer_group_id') ."',
                                  `quantity` = '". (int) $quantityRange['key'] ."',
                                  `priority` = '". (int) $priority ."',
                                  `price` = '". (float) $quantityRange['value'] ."'
                                 ");
                                $priority++;
                            }
                        }

                        if(isset($specialPrice) && !empty($specialPrice))
                        {
                            $this->db->query("INSERT INTO `". DB_PREFIX ."product_special` SET 
                            `product_id` = '". (int) $product_id ."', 
                            `customer_group_id` = '". (int) $this->config->get('config_customer_group_id') ."',
                            `priority` = '1',
                            `price` = '". (float) $specialPrice ."'
                            ");
                        }

                        $this->prepareProductOptions($product, $product_id); 
                    }
                    if(!empty($product_id))
                        $product_ids[] = $product_id;
                    elseif(!empty($existingProduct->row['product_id']))
                        $existing_product_ids[] = $existingProduct->row['product_id'];
                } // product data foreach ends here

                if(!empty($product_ids))
                    $json = array('success' => true, 'message' => implode(',', $product_ids) .'-Products Fetched Successfully!');
                elseif(!empty($existing_product_ids))
                    $json = array('success' => true, 'message' => implode(',', $existing_product_ids) . '-Product(s) already imported!');
                else
                    $json = array('success' => false, 'message' => 'Error importing Product!');
                
            } catch(Exception $e){
                $this->log("CedSunskyImporterLibrary::prepareProductData", 6, true);
                $this->log($e->getMessage(), 6, true);
                $json = array('success' => false, 'message' => $e->getMessage());
            }
        }
        return $json;
    }

    public function prepareProductOptions($product, $product_id)
    {
        if(is_array($product) && !empty($product) && !empty($product_id))
        {
            if(isset($product['modelLabel']) && !empty($product['modelLabel']))
            {
                try
                {
                    $options_data = [];
                    if(strpos($product['modelLabel'], '$'))
                    {
                        $options = explode('$', $product['modelLabel']);
                        foreach($options as $index => $option)
                        {
                           $product_option = $this->createProductOptions($option, $product['modelList']);
                        }
                        $options_data[] = array(
                                'product_option' => $product_option,
                            );
                    } else {
                        $option = $product['modelLabel'];
                        $product_option = $this->createProductOptions($option, $product['modelList']);
                        $options_data[] = array(
                            'product_option' => $product_option,
                        );
                    }

                    if (!empty($options_data) && is_array($options_data)) 
                    {
                        foreach($options_data as $key => $data)
                        {
                            foreach ($data['product_option'] as $product_option) 
                            {
                                //$product_option = $data['product_option'];
                                if ($product_option['type'] == 'select' || $product_option['type'] == 'radio') 
                                {
                                    if (isset($product_option['product_option_value'])) 
                                    {
                                        $this->db->query("INSERT INTO " . DB_PREFIX . "product_option SET product_id = '" . (int)$product_id . "', option_id = '" . (int)$product_option['option_id'] . "', required = '" . (int)$product_option['required'] . "'");
                                        $product_option_id = $this->db->getLastId();
                                        foreach ($product_option['product_option_value'] as $product_option_value) 
                                        {
                                            $this->db->query("INSERT INTO " . DB_PREFIX . "product_option_value SET product_option_id = '" . (int)$product_option_id . "', product_id = '" . (int)$product_id . "', option_id = '" . (int)$product_option['option_id'] . "', option_value_id = '" . (int)$product_option_value['option_value_id'] . "', quantity = '" . (int)$product_option_value['quantity'] . "', subtract = '" . (int)$product_option_value['subtract'] . "', price = '" . (float)$product_option_value['price'] . "', price_prefix = '" . $this->db->escape($product_option_value['price_prefix']) . "', points = '" . (int)$product_option_value['points'] . "', points_prefix = '" . $this->db->escape($product_option_value['points_prefix']) . "', weight = '" . (float)$product_option_value['weight'] . "', weight_prefix = '" . $this->db->escape($product_option_value['weight_prefix']) . "'");
                                        }
                                    }
                                } else {
                                    $this->db->query("INSERT INTO " . DB_PREFIX . "product_option SET product_id = '" . (int)$product_id . "', option_id = '" . (int)$product_option['option_id'] . "', value = '', required = '" . (int)$product_option['required'] . "'");
                                }
                            }
                        }
                    } // options if ends here
                } catch(Exception $e)
                {
                    $this->log("CedSunskyImporterLibrary::prepareProductOptions", 6, true);
                    $this->log($e->getMessage(), 6, true);
                    echo '<pre>'; print_r($e->getMessage()); die;
                }
                
            }
        }
    }

    public function createProductOptions($option, $option_value_list)
    {
        try
        {
            $language_id = $this->config->get('ced_sunsky_importer_language');
            if(isset($option) && ($option == 'Color'))
            {
                $type = 'select';
                //$name = $option_value;
                $option_name = $option;
                $sortOrder = '4';
            } elseif(isset($option) && ($option == 'Size'))
            {
                $type = 'radio';
                //$name = $option_value;
                $option_name = $option;
                $sortOrder = '1';
            }

            $optionExist = $this->db->query("SELECT `option_id` FROM `". DB_PREFIX."option_description` WHERE `name` = '". $this->db->escape($option_name) ."' AND language_id = '" . (int)$language_id ."' ");

            if ($optionExist->num_rows == 0) {
                $this->db->query("INSERT INTO `" . DB_PREFIX . "option` SET type = '". $this->db->escape($type) ."', sort_order = '". (int)$sortOrder ."' ");
                $option_id = $this->db->getLastId();
                $this->db->query("INSERT INTO `" . DB_PREFIX . "option_description` SET option_id = '" . (int)$option_id .
                    "', language_id = '" . (int)$language_id .
                    "', name = '" . $this->db->escape($option_name) . "'");
            } else {
                $option_id = $optionExist->row['option_id'];
            }

            $product_option_value = [];
            $product_option = [];
            $sort_order = '1';

            foreach($option_value_list as $key => $optionValue)
            {
                if(strpos($optionValue['value'], '$'))
                {
                    $optionValues = explode('$', $optionValue['value']);
                    if($option == 'Color')
                        $name = $optionValues['0'];
                    else
                        $name = $optionValues['1'];
                } else {
                    $name = $optionValue['value'];
                }

                if(isset($option_id) && !empty($option_id))
                {
                    $sql = $this->db->query("SELECT `option_value_id`, `name` FROM `". DB_PREFIX."option_value_description` WHERE `option_id` = '". (int)$option_id ."' AND `language_id` = '". (int)$language_id ."' AND `name` = '". $this->db->escape($name) ."' ");
                    if($sql->num_rows)
                    {
                        $result = $sql->rows;
                    
                        $option_value = '';
                        foreach($result as $k => $v){
                            $option_value .= $v['name'] . ',';
                        }

                        if(isset($name) && is_array($option_value) && !in_array($name, $option_value))
                        {
                            $this->db->query("INSERT INTO `". DB_PREFIX."option_value` SET `option_id` = '". (int)$option_id ."', `image` = '', `sort_order` = '". $sort_order ."' ");

                            $option_value_id = $this->db->getLastId();

                            $this->db->query("INSERT INTO `". DB_PREFIX."option_value_description` SET `option_value_id` = '". (int)$option_value_id ."', `option_id` = '". (int)$option_id ."', `language_id` = '". (int)$language_id ."', `name` = '". $this->db->escape($name) ."' ");

                        $sort_order++;
                        } else {
                            $option_value_id = $sql->row['option_value_id'];
                        }
                    } else {
                        $this->db->query("INSERT INTO `". DB_PREFIX."option_value` SET `option_id` = '". (int)$option_id ."', `image` = '', `sort_order` = '". $sort_order ."' ");

                        $option_value_id = $this->db->getLastId();

                        $this->db->query("INSERT INTO `". DB_PREFIX."option_value_description` SET `option_value_id` = '". (int)$option_value_id ."', `option_id` = '". (int)$option_id ."', `language_id` = '". (int)$language_id ."', `name` = '". $this->db->escape($name) ."' ");
                        $sort_order++;
                    }
                }

                $option_value_id = isset($option_value_id) ? $option_value_id : '0';
                $product_option_value[] = [
                    'option_value_id' => $option_value_id,
                    'name' => $name,
                    'quantity' => '0',
                    'subtract' => '1',
                    'price' => '0.00',
                    'price_prefix' => '+',
                    'points' => '0',
                    'points_prefix' => '+',
                    'weight' => '0.00',
                    'weight_prefix' => '+'
                ];

                if($option_id && isset($product_option[$option_id]) && isset($product_option[$option_id]['type'])) {
                    $product_option[$option_id]['product_option_value'] =  $product_option_value;
                } else if($option_id){
                    $product_option[$option_id] = array(
                        'type' => $type,
                        'option_id' => $option_id,
                        'required' => '1',
                        'product_option_value' => $product_option_value,
                    );
                }

            } // Option Value list foreach ends here

            return $product_option;
        } catch(Exception $e)
        {
            $this->log("CedSunskyImporterLibrary::createProductOptions", 6, true);
            $this->log($e->getMessage(), 6, true);
            echo '<pre>'; print_r($e->getMessage()); die;
        }
    }

    public function fetchOrders($post_data)
    {
        $url = 'order!getOrderList.do';
        $params = array(
            'status' => $post_data['status'],
            'siteNumber' => $post_data['siteNumber'],
            'gmtCreatedStart' => $post_data['gmtCreatedStart'],
            'gmtCreatedEnd' => $post_data['gmtCreatedEnd']
            );
        $response = $this->getProductData($url, $params);

        $this->log($response);
        try {
            $errorMessage= '';
            if ($response) {
                if (isset($response['success']) && $response['success']) {
                    if (isset($response['message']['result']) && $response['message']['result']) 
                    {
                        $response = $response['message']['result'];
                        
                        if (!isset($response['0'])) {
                            $temp_array = $response;
                            $response = array();
                            $response['0'] = $temp_array;
                        }
                        $order_ids = array();

                        if (is_array($response))
                        {
                            $totalOrderFetched = count($response);

                            foreach ($response as $key => $value) {

                                if (isset($value['number']) && $value['number']) {
                                    $order_id = $value['number'];
                                    $already_exist = $this->isSunskyOrderIdExist($order_id, $value);

                                    if($already_exist ) {
                                        continue;
                                    } else {

                                        $order_ids[] = $this->prepareOrderData($value);

                                        $this->log(json_encode($value),'6',true);

                                        $order_ids = array_filter($order_ids);
                                    }
                                }
                            }

                            if (count($order_ids) == $totalOrderFetched) {
                                return array('success' => true ,'message' => $order_ids);
                            } else if(count($order_ids) && ($totalOrderFetched > count($order_ids))) {
                                return array('success' => true ,'message' => $order_ids,'sub_message' => 'Please see Rejected List too.');
                            } else if(count($order_ids)==0) {
                                return array('success' => true ,'message' => 'No new Order Found.');
                            } else {
                                return array('success' => false ,'message' => 'Order Send to Rejected List.');
                            }

                            
                        } 
                    } else {
                        return $response;
                    }
                    if ($errorMessage) {
                        return array('success' => false ,'message' => $errorMessage);
                    }
                } else {

                    return array('success' => false ,'message' => $response['message']);
                }
            } else {
                return array('success' => false ,'message' =>$this->language->get('error_module'));
            }
        }
        catch(Exception $e) {
            $this->log('Order Error:  ' . var_export($response, true));
            $this->log('Order Error Message : ' .$e->getMessage());
            return array('success' => false ,'message' => $e->getMessage());
        }
    }

    public function isSunskyOrderIdExist($order_id = 0, $orderData = array())
    {
        $isExist = false ;
        if ($order_id) {
            $sql = "SELECT `id` FROM `" . DB_PREFIX . "ced_sunsky_importer_order` WHERE `sunsky_order_id` = '".$order_id."'";

            $result = $this->db->query($sql);

            if ($result->num_rows) {    
                $isExist = true ;
            }
        }
        return $isExist;
    }

    public function prepareOrderData( $data = array()) {
        if ($data) {
            $opencart_order_id = 0;
            $order_id = $data['number'];

            if (!$this->isSunskyOrderIdExist($order_id, $data)) {
                $id = $this->createSunskyOrder($data);
                if($id)
                    return $id;
            }
        }
    }
    public function createSunskyOrder($data) {

        $order_data   = array();

        $orderId              = $data['number'];

        $url = 'order!getOrderDetails.do';
        $params = array('number' => $orderId);
        $order_data = $this->getProductData($url, $params);
        if(isset($order_data['success']) && ($order_data['success'] == true) && is_array($order_data['message']))
        {
            $data = $order_data['message'];
        }
        
        $customerOrderId      = isset($data['siteNumber']) ? $data['siteNumber'] : $data['number'];
        
        $orderDate            = date('Y-m-d H:i:s', $data['gmtCreated']);
        
        $orderStatus = $data['status'];

        if($orderStatus == '1')
            $orderStatus = 'Pending';
        elseif($orderStatus == '2')
            $orderStatus = 'Processing';
        elseif($orderStatus == '3')
            $orderStatus = 'Shipped';
        elseif($orderStatus == '4')
            $orderStatus = 'Canceled';
        elseif($orderStatus == '5')
            $orderStatus = 'Processed';

        $email = $orderId.'@cedsunskycustomer.com';

        if(isset($data['deliveryAddress']) && !empty($data['deliveryAddress']))
        {
            $shippingAddress = $data['deliveryAddress'];

            $name = explode(' ', $shippingAddress['receiver']);

            $firstName    = $name[0];
            $lastName     = @$name[1];
            $streetAddress = $shippingAddress['address'];
            $streetAddress2 = $shippingAddress['address2'];
            $city         = $shippingAddress['city'];
            $state        = $shippingAddress['state'];
            $postalCode   = $shippingAddress['postcode'];
            $countryId    = $shippingAddress['countryId'];
            $phoneNumber  = $shippingAddress['telephone'];
        }

        $shippingMethod      = $data['shippingWay']['name'];

        // Order Array
        $order_data['invoice_prefix']     = $this->config->get('config_invoice_prefix');
        $order_data['store_id']           = $this->config->get('config_store_id');
        $order_data['store_name']         = $this->config->get('config_name');
        $order_data['store_url']          = HTTPS_SERVER;
        $order_data['customer_id']        = $customerOrderId;
        $order_data['customer_group_id']  = '1';
        $order_data['firstname']          = $firstName;
        $order_data['lastname']           = $lastName;
        $order_data['email']              = $email;
        $order_data['telephone']          = $phoneNumber;
        $order_data['fax']                = '';
        $order_data['order_status']       = $orderStatus;
        $order_data['custom_field']       = array();

        // Payment Detail
        $order_data['payment_firstname']  = $firstName;
        $order_data['payment_lastname']   = $lastName;
        $order_data['payment_company']    = '';
        $order_data['payment_address_1']  = $streetAddress;
        $order_data['payment_address_2']  = !empty($streetAddress2) ? $streetAddress2 : '';
        $order_data['payment_city']       = $city;
        $order_data['payment_postcode']   = $postalCode;
        $localizedInfo = $this->fetchCountryState($state, $countryId);
        $order_data['payment_zone']       = isset($localizedInfo['zone_name']) ? $localizedInfo['zone_name'] : '';
        $order_data['payment_zone_id']    = isset($localizedInfo['zone_id']) ? $localizedInfo['zone_id'] : '0';
        $order_data['payment_country']    = isset($localizedInfo['country_name']) ? $localizedInfo['country_name'] : '';
        $order_data['payment_country_id'] = isset($localizedInfo['country_id']) ? $localizedInfo['country_id'] : '0';
        $order_data['payment_address_format'] = '';
        $order_data['payment_custom_field']   = array();
        $order_data['payment_method']         = 'Sunsky Payment';
        $order_data['payment_code']           = 'SunskyPayment';
        $order_data['payment_language']       = '';
        $order_data['payment_language_id']    = '0';
        $order_data['payment_currency']       = '';
        $order_data['payment_currency_id']    = '0';

        // Shipping Detail
        $order_data['shipping_firstname']         = $firstName;
        $order_data['shipping_lastname']          = $lastName;
        $order_data['shipping_company']           = '';
        $order_data['shipping_address_1']         = $streetAddress;
        $order_data['shipping_address_2']         = !empty($streetAddress2) ? $streetAddress2 : '';
        $order_data['shipping_city']              = $city;
        $order_data['shipping_postcode']          = $postalCode;
        $order_data['shipping_zone']              = isset($localizedInfo['zone_name']) ? $localizedInfo['zone_name'] : '';
        $order_data['shipping_zone_id']           = isset($localizedInfo['zone_id']) ? $localizedInfo['zone_id'] : '0';
        $order_data['shipping_country']           = isset($localizedInfo['country_name']) ? $localizedInfo['country_name'] : '';
        $order_data['shipping_country_id']        = isset($localizedInfo['country_id']) ? $localizedInfo['country_id'] : '0';
        $order_data['shipping_address_format']    = '';
        $order_data['shipping_custom_field']      = array( );
        $order_data['shipping_method']            = isset($shippingMethod) ? $shippingMethod : 'Sunsky Shipping';
        $order_data['shipping_code']              = 'SunskyShipping.SunskyShipping';

        // for products
        
        $total_shipping_cost = isset($data['shippingCost']) ? $data['shippingCost'] : 0;
        $subtotal = isset($data['amount']) ? $data['amount'] : 0;

        $order_items  = $data['detailList'];
        
        if($order_items && count($order_items))
        {
            if(!isset($order_items['0']))
            {
                $temp_results = $order_items;
                $order_items = array();
                $order_items['0'] = $temp_results;
            }

            foreach($order_items as $key => $item)
            {
                $item_cost = isset($item['price']) ? (float)$item['price'] : 0;
                $qty = isset($item['qty']) ? $item['qty'] : '0';

                $ordered_products = $this->getOpencartProductBySku($item['productId'], $item['itemNo'], $qty, $item, $orderId, $item['title'], $item_cost);

                if($ordered_products)
                    $order_data['products'][] = $ordered_products;
            }
        }

        if(isset($order_data['products']) && count($order_data['products'])>0)
        {
            $order_data['vouchers']=array();

            $order_data['totals'][]= array(
                'code' => 'sub_total',
                'title' => 'Sub-Total',
                'value'=> $subtotal,
                'sort_order' => 1
            );

            $order_data['totals'][]= array(
                'code' => 'shipping',
                'title' => 'Sunsky Shipping',
                'value'=>(float) $total_shipping_cost,
                'sort_order' => 3
            );

            $order_data['totals'][]= array(
                'code' => 'total',
                'title' => 'Total',
                'value'=> (float) $data['totalAmount'],
                'sort_order' => 9
            );

            $order_data['comment']='';
            $order_data['total']= (float) $data['totalAmount'];
            $order_data['affiliate_id']='0';
            $order_data['commission']='0';
            $order_data['marketing_id']='0';
            $order_data['tracking']='';
            $order_data['language_id'] = $this->config->get('ced_sunsky_importer_language');

            if (isset($this->session->data['currency']) && !empty($this->session->data['currency'])) {
                 $order_data['currency_id'] = $this->currency->getId($this->session->data['currency']);
                 $order_data['currency_code'] = $this->session->data['currency'];
                 $order_data['currency_value'] = $this->currency->getValue($this->session->data['currency']);
            } else {
                $order_data['currency_id'] = '2';
                $order_data['currency_code'] = 'USD';
                $order_data['currency_value'] = '1';
            }

            $order_data['ip'] = '';
            $order_data['forwarded_ip'] = '';
            $order_data['user_agent'] = '';
            $order_data['accept_language'] = '';

            $opencart_order_id = $this->addSunskyOrder($order_data);
            $respo = $this->db->query("INSERT INTO " . DB_PREFIX . "ced_sunsky_importer_order SET opencart_order_id =  '" . (int)$opencart_order_id . "', sunsky_order_id='".$orderId."', sunsky_status = '". $this->db->escape(strtoupper($orderStatus)) ."', order_data='".$this->db->escape(json_encode($data))."', `order_place_date` = '" . $this->db->escape($orderDate) . "' ");

            if($respo)
            {
                $order_ids[] = $opencart_order_id;
            }
        } else {
            $this->session->data['success'] = "Sunsky Order Can not Imported see Rejected List";
        }

        if (!empty($opencart_order_id)) {
            return $opencart_order_id;
        }
        return false;
    }

    public function fetchCountryState($state, $country_id)
    {
        $response = array();
        if(isset($country_id) && $country_id)
        {
            $countryStateExist = $this->db->query("SELECT * FROM `". DB_PREFIX ."ced_sunsky_importer_country` WHERE `id` = '". (int) $country_id ."' ");
            if($countryStateExist->num_rows)
            {
                $country = $this->db->query("SELECT c.`country_id`, sc.`name` FROM `". DB_PREFIX ."country` AS c LEFT JOIN `". DB_PREFIX ."ced_sunsky_importer_country` AS sc ON (c.`iso_code_2` = sc.`code`) WHERE sc.`id` = '". (int) $country_id ."' ");

                $state = $this->db->query("SELECT z.`zone_id`, ss.`name` FROM `". DB_PREFIX ."zone` AS z LEFT JOIN `". DB_PREFIX ."ced_sunsky_importer_state` AS ss ON (z.`code` = ss.`code`) WHERE ss.`country_id` = '". (int) $country_id ."' AND ss.`name` = '". $this->db->escape($state) ."' ");
                $response = array(
                    'country_id' => $country->row['country_id'],
                    'country_name' => $country->row['name'],
                    'zone_id' => isset($state->row['zone_id']) ? $state->row['zone_id'] : '0',
                    'zone_name' => isset($state->row['name']) ? $state->row['name'] : ''
                    );
            } else {
                $url = 'order!getCountries.do';
                $params = array();
                $response = $this->getProductData($url, $params);
                //echo '<pre>'; print_r($response); die;
                if(isset($response['success']) && $response['success'])
                {
                    foreach($response['message'] as $key=> $value)
                    {
                        $this->db->query("INSERT INTO `". DB_PREFIX ."ced_sunsky_importer_country` SET `id` = '". (int) $value['id'] ."', `name` = '". $this->db->escape($value['name']) ."', `code` = '". $this->db->escape($value['code']) ."', `shipToState` = '". (boolean) $value['shipToState'] ."' ");
                        if(isset($value['stateList']) && $value['stateList'])
                        {
                            foreach($value['stateList'] as $index => $state)
                            {
                                $this->db->query("INSERT INTO `". DB_PREFIX ."ced_sunsky_importer_state` SET `country_id` = '". (int) $value['id'] ."', `name` = '". $this->db->escape($state['name']) ."', `code` = '". $this->db->escape($state['code']) ."' ");
                            }
                        }
                    }
                }
                $country = $this->db->query("SELECT c.`country_id`, sc.`name` FROM `". DB_PREFIX ."country` AS c LEFT JOIN `". DB_PREFIX ."ced_sunsky_importer_country` AS sc ON (c.`iso_code_2` = sc.`code`) WHERE sc.`id` = '". (int) $country_id ."' ");

                $state = $this->db->query("SELECT z.`zone_id`, ss.`name` FROM `". DB_PREFIX ."zone` AS z LEFT JOIN `". DB_PREFIX ."ced_sunsky_importer_state` AS ss ON (z.`code` = ss.`code`) WHERE ss.`country_id` = '". (int) $country_id ."' AND ss.`name` = '". $this->db->escape($name) ."' ");
                $response = array(
                    'country_id' => $country->row['country_id'],
                    'country_name' => $country->row['name'],
                    'zone_id' => isset($state->row['zone_id']) ? $state->row['zone_id'] : '0',
                    'zone_name' => isset($state->row['name']) ? $state->row['name'] : ''
                    );
            }
        } else {
            $response = array(
            'country_id' => '0',
            'country_name' => '',
            'zone_id' => '0',
            'zone_name' => ''
            );
        }
        return $response;
    }

    public function getOpencartProductBySku($product_id, $sku, $quantity, $order_data, $sunsky_order_id, $product_title, $sunsky_price, $totalVat = 0)
    {
        $product=array();
        $sql = "SELECT `status`,`minimum`,`quantity`,`model`,`price`FROM `".DB_PREFIX ."product` WHERE product_id = '". (int) $product_id."' ";
        $query = $this->db->query($sql);

        if($query->num_rows)
        {
            $status     =$query->row['status'];
            $minimum    =$query->row['minimum'];
            $qty_avail  =$query->row['quantity'];
            $model      =$query->row['model'];
            $price      =$query->row['price'];

            if($status)
            {
                if(($qty_avail >= $quantity))
                {
                    $product['quantity']  = $quantity;
                    $product['product_id']= $product_id;
                    $product['model']     = $model;
                    $product['subtract']  = $quantity;
                    $product['price']     = ($sunsky_price) ? $sunsky_price : $price;
                    $product['total']     = ($sunsky_price) ? $quantity * $sunsky_price : $quantity * $price;
                    $product['tax']       = ($totalVat) ? $totalVat : '0';
                    $product['reward']    = 0;
                    $product['name']      = $product_title;
                    $product['option']    = '{}';
                    $product['download']  = array();
                    return $product;
                } else {
                    $this->addOrderErrorInfo($sunsky_order_id, $order_data,"REQUESTED QUANTITY FOR PRODUCT ID ".$product_id." IS NOT AVAILABLE", $sku);
                    return '0';
                }
            } else {
                $this->addOrderErrorInfo($sunsky_order_id, $order_data,"REQUESTED QUANTITY FOR PRODUCT ID ".$product_id." IS NOT AVAILABLE", $sku);
                return '0';
            }
        } else {
            $sql = "SELECT `product_id`, `status`, `minimum`, `quantity`, `model`, `price` FROM `" . DB_PREFIX . "product` WHERE `sku` = '".$sku."'";
            $product_data = $query = $this->db->query($sql);

            if($product_data && $product_data->num_rows && isset($product_data->row['product_id']))
            {
                $product_id = $product_data->row['product_id'];
                $status     = $product_data->row['status'];
                $minimum    = $product_data->row['minimum'];
                $qty_avail  = $product_data->row['quantity'];
                $model      = $product_data->row['model'];
                $price      = $product_data->row['price'];
                if($status)
                {
                    if(($qty_avail >= $quantity))
                    {
                        $product['quantity']  = $quantity;
                        $product['product_id']= $product_id;
                        $product['model']     = $model;
                        $product['subtract']  = $quantity;
                        $product['price']     = ($sunsky_price) ? $sunsky_price : $price;
                        $product['total']     = ($sunsky_price) ? $quantity * $sunsky_price : $quantity * $price;
                        $product['tax']       = ($totalVat) ? $totalVat : '0';
                        $product['reward']    = 0;
                        $product['name']      = $product_title;
                        $product['option']    = array();
                        $product['download']  = array();
                        return $product;
                    } else {
                        $this->addOrderErrorInfo($sunsky_order_id, $order_data,"REQUESTED QUANTITY FOR PRODUCT ID ".$product_id." IS NOT AVAILABLE", $sku);
                        return '0';
                    }
                } else {
                    $this->addOrderErrorInfo($sunsky_order_id, $order_data,"PRODUCT STATUS IS DISABLED WITH ID ".$product_id, $sku);
                    return '0';
                }
            } else {
                $this->addOrderErrorInfo($sunsky_order_id, $order_data,"MERCHANT SKU OR PRODUCT DOES NOT EXIST", $sku);
                return '0';
            }
        }
    }
    public function addOrderErrorInfo($sunsky_order_id, $order_data, $error_message, $sku)
    {
        $already_exists = " SELECT * FROM `" . DB_PREFIX . "ced_sunsky_importer_order_error` WHERE `merchant_sku` = '" . $sku . "' AND ced_sunsky_order_id = '" . $sunsky_order_id . "' ";
        $already_exists=$this->db->query($already_exists);
        if(!$already_exists->num_rows)
        {
            $sql = " INSERT INTO `" . DB_PREFIX . "ced_sunsky_importer_order_error` (`merchant_sku`, `ced_sunsky_order_id`, `order_data`, `reason`)VALUES('" . $sku . "', '" . $sunsky_order_id . "', '" . $this->db->escape(json_encode($order_data)) . "', '" . $error_message . "')";
            $result=$this->db->query($sql);
            if($result){
                return $sunsky_order_id;
            }
        }
    }

    public function addSunskyOrder($data)
    {
        $this->db->query("INSERT INTO `" . DB_PREFIX . "order` SET invoice_prefix = '" . $this->db->escape($data['invoice_prefix']) . "', store_id = '" . (int)$data['store_id'] . "', store_name = '" . $this->db->escape($data['store_name']) . "', store_url = '" . $this->db->escape($data['store_url']) . "', customer_id = '" . (int)$data['customer_id'] . "', customer_group_id = '" . (int)$data['customer_group_id'] . "', firstname = '" . $this->db->escape($data['firstname']) . "', lastname = '" . $this->db->escape($data['lastname']) . "', email = '" . $this->db->escape($data['email']) . "', telephone = '" . $this->db->escape($data['telephone']) . "', fax = '" . $this->db->escape($data['fax']) . "', custom_field = '" . $this->db->escape(isset($data['custom_field']) ? serialize($data['custom_field']) : '') . "', payment_firstname = '" . $this->db->escape($data['payment_firstname']) . "', payment_lastname = '" . $this->db->escape($data['payment_lastname']) . "', payment_company = '" . $this->db->escape($data['payment_company']) . "', payment_address_1 = '" . $this->db->escape($data['payment_address_1']) . "', payment_address_2 = '" . $this->db->escape($data['payment_address_2']) . "', payment_city = '" . $this->db->escape($data['payment_city']) . "', payment_postcode = '" . $this->db->escape($data['payment_postcode']) . "', payment_country = '" . $this->db->escape($data['payment_country']) . "', payment_country_id = '" . (int)$data['payment_country_id'] . "', payment_zone = '" . $this->db->escape($data['payment_zone']) . "', payment_zone_id = '" . (int)$data['payment_zone_id'] . "', payment_address_format = '" . $this->db->escape($data['payment_address_format']) . "', payment_custom_field = '" . $this->db->escape(isset($data['payment_custom_field']) ? serialize($data['payment_custom_field']) : '') . "', payment_method = '" . $this->db->escape($data['payment_method']) . "', payment_code = '" . $this->db->escape($data['payment_code']) . "', shipping_firstname = '" . $this->db->escape($data['shipping_firstname']) . "', shipping_lastname = '" . $this->db->escape($data['shipping_lastname']) . "', shipping_company = '" . $this->db->escape($data['shipping_company']) . "', shipping_address_1 = '" . $this->db->escape($data['shipping_address_1']) . "', shipping_address_2 = '" . $this->db->escape($data['shipping_address_2']) . "', shipping_city = '" . $this->db->escape($data['shipping_city']) . "', shipping_postcode = '" . $this->db->escape($data['shipping_postcode']) . "', shipping_country = '" . $this->db->escape($data['shipping_country']) . "', shipping_country_id = '" . (int)$data['shipping_country_id'] . "', shipping_zone = '" . $this->db->escape($data['shipping_zone']) . "', shipping_zone_id = '" . (int)$data['shipping_zone_id'] . "', shipping_address_format = '" . $this->db->escape($data['shipping_address_format']) . "', shipping_custom_field = '" . $this->db->escape(isset($data['shipping_custom_field']) ? serialize($data['shipping_custom_field']) : '') . "', shipping_method = '" . $this->db->escape($data['shipping_method']) . "', shipping_code = '" . $this->db->escape($data['shipping_code']) . "', comment = '" . $this->db->escape($data['comment']) . "', total = '" . (float)$data['total'] . "', affiliate_id = '" . (int)$data['affiliate_id'] . "', commission = '" . (float)$data['commission'] . "', marketing_id = '" . (int)$data['marketing_id'] . "', tracking = '" . $this->db->escape($data['tracking']) . "', language_id = '" . (int)$data['language_id'] . "', currency_id = '" . (int)$data['currency_id'] . "', currency_code = '" . $this->db->escape($data['currency_code']) . "', currency_value = '" . (float)$data['currency_value'] . "', ip = '" . $this->db->escape($data['ip']) . "', forwarded_ip = '" .  $this->db->escape($data['forwarded_ip']) . "', user_agent = '" . $this->db->escape($data['user_agent']) . "', accept_language = '" . $this->db->escape($data['accept_language']) . "', date_added = NOW(), date_modified = NOW() , order_status_id='".$this->getOrderStatusIdByName($data['order_status'])."'");

        $order_id = $this->db->getLastId();

        // Products
        foreach ($data['products'] as $product) {
            $this->db->query("INSERT INTO " . DB_PREFIX . "order_product SET order_id = '" . (int)$order_id . "', product_id = '" . (int)$product['product_id'] . "', name = '" . $this->db->escape($product['name']) . "', model = '" . $this->db->escape($product['model']) . "', quantity = '" . (int)$product['quantity'] . "', price = '" . (float)$product['price'] . "', total = '" . (float)$product['total'] . "', tax = '" . (float)$product['tax'] . "', reward = '" . (int)$product['reward'] . "'");

            $order_product_id = $this->db->getLastId();

            if(isset($product['option']) && count($product['option'])>0){
                foreach ($product['option'] as $option_id => $option_value) {

                $sql="SELECT pov.product_option_value_id,po.product_option_id,od.name, ovd.name as `value`,o.type FROM ".DB_PREFIX."product_option_value pov LEFT JOIN ".DB_PREFIX."product_option po ON (po.product_id=pov.product_id AND po.option_id=pov.option_id) LEFT JOIN ".DB_PREFIX."option o ON (pov.option_id =o.option_id) LEFT JOIN ".DB_PREFIX."option_description od ON (pov.option_id =od.option_id AND od.language_id = '" . (int)$data['language_id'] . "') JOIN ".DB_PREFIX."option_value_description ovd ON (pov.option_id =ovd.option_id AND pov.option_value_id=ovd.option_value_id AND ovd.language_id = '" . (int)$data['language_id'] . "') WHERE pov.option_value_id =". (int)$option_value." and pov.product_id=".(int)$product['product_id'];

                    $options_data=$this->db->query($sql);
                    if($options_data->num_rows){
                        $option=$options_data->row;
                        $this->db->query("INSERT INTO " . DB_PREFIX . "order_option SET order_id = '" . (int)$order_id . "', order_product_id = '" . (int)$order_product_id . "', product_option_id = '" . (int)$option['product_option_id'] . "', product_option_value_id = '" . (int)$option['product_option_value_id'] . "', name = '" . $this->db->escape($option['name']) . "', `value` = '" . $this->db->escape($option['value']) . "', `type` = '" . $this->db->escape($option['type']) . "'");
                    }
                }
            }
        }

        // Totals
        foreach ($data['totals'] as $total) {
            $this->db->query("INSERT INTO " . DB_PREFIX . "order_total SET order_id = '" . (int)$order_id . "', code = '" . $this->db->escape($total['code']) . "', title = '" . $this->db->escape($total['title']) . "', `value` = '" . (float)$total['value'] . "', sort_order = '" . (int)$total['sort_order'] . "'");
        }

        $this->addOrderHistory($order_id, $this->getOrderStatusIdByName($data['order_status']));

        return $order_id;
    }

    public function addOrderHistory($order_id, $order_status_id, $comment ='',$notify = true)
    {
        $this->db->query("INSERT INTO " . DB_PREFIX . "order_history SET order_id = '" . (int)$order_id . "', order_status_id = '" . (int)$order_status_id . "', notify = '" . (int)$notify . "', comment = '" . $this->db->escape($comment) . "', date_added = NOW()");
        $data=array();
        $data['order_status_id']=(int)$order_status_id;
        $data['order_id']=(int)$order_id;
        $data['comment']='A Sunsky Order Imported Successfully';
        $data['notify']=(int)$notify;

        $order_info = $this->getOrder($order_id);

        if ($order_info) {
            // Restock
            $product_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "order_product WHERE order_id = '" . (int)$order_id . "'");

            foreach($product_query->rows as $product) {
                $this->db->query("UPDATE `" . DB_PREFIX . "product` SET quantity = (quantity - " . (int)$product['quantity'] . ") WHERE product_id = '" . (int)$product['product_id'] . "' AND subtract = '1'");

                $option_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "order_option WHERE order_id = '" . (int)$order_id . "' AND order_product_id = '" . (int)$product['order_product_id'] . "'");

                foreach ($option_query->rows as $option) {
                    $this->db->query("UPDATE " . DB_PREFIX . "product_option_value SET quantity = (quantity - " . (int)$product['quantity'] . ") WHERE product_option_value_id = '" . (int)$option['product_option_value_id'] . "' AND subtract = '1'");
                }
            }

            // If order status is 0 then becomes greater than 0 send main html email
            if ($order_status_id) {
                // Load the language for any mails that might be required to be sent out
                $language = new Language($order_info['language_code']);
                $language->load($order_info['language_code']);
                $language->load('mail/order');

                $order_status_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "order_status WHERE order_status_id = '" . (int)$order_status_id . "' AND language_id = '" . (int)$order_info['language_id'] . "'");

                if ($order_status_query->num_rows) {
                    $order_status = $order_status_query->row['name'];
                } else {
                    $order_status = '';
                }

                $subject = sprintf($language->get('text_new_subject'), html_entity_decode($order_info['store_name'], ENT_QUOTES, 'UTF-8'), $order_id);

                // HTML Mail
                $data = array();

                $data['title'] = sprintf($language->get('text_new_subject'), $order_info['store_name'], $order_id);

                $data['text_greeting'] = sprintf($language->get('text_new_greeting'), $order_info['store_name']);
                $data['text_link'] = $language->get('text_new_link');
                $data['text_download'] = $language->get('text_new_download');
                $data['text_order_detail'] = $language->get('text_new_order_detail');
                $data['text_instruction'] = $language->get('text_new_instruction');
                $data['text_order_id'] = $language->get('text_new_order_id');
                $data['text_date_added'] = $language->get('text_new_date_added');
                $data['text_payment_method'] = $language->get('text_new_payment_method');
                $data['text_shipping_method'] = $language->get('text_new_shipping_method');
                $data['text_email'] = $language->get('text_new_email');
                $data['text_telephone'] = $language->get('text_new_telephone');
                $data['text_ip'] = $language->get('text_new_ip');
                $data['text_order_status'] = $language->get('text_new_order_status');
                $data['text_payment_address'] = $language->get('text_new_payment_address');
                $data['text_shipping_address'] = $language->get('text_new_shipping_address');
                $data['text_product'] = $language->get('text_new_product');
                $data['text_model'] = $language->get('text_new_model');
                $data['text_quantity'] = $language->get('text_new_quantity');
                $data['text_price'] = $language->get('text_new_price');
                $data['text_total'] = $language->get('text_new_total');
                $data['text_footer'] = $language->get('text_new_footer');

                $data['logo'] = $this->config->get('config_url') . 'image/' . $this->config->get('config_logo');
                $data['store_name'] = $order_info['store_name'];
                $data['store_url'] = $order_info['store_url'];
                $data['customer_id'] = $order_info['customer_id'];
                $data['link'] = $order_info['store_url'] . 'index.php?route=account/order/info&order_id=' . $order_id;

                $data['order_id'] = $order_id;
                $data['date_added'] = date($language->get('date_format_short'), strtotime($order_info['date_added']));
                $data['payment_method'] = $order_info['payment_method'];
                $data['shipping_method'] = $order_info['shipping_method'];
                $data['email'] = $order_info['email'];
                $data['telephone'] = $order_info['telephone'];
                $data['ip'] = $order_info['ip'];
                $data['order_status'] = $order_status;

                if ($comment && $notify) {
                    $data['comment'] = nl2br($comment);
                } else {
                    $data['comment'] = '';
                }

                if ($order_info['payment_address_format']) {
                    $format = $order_info['payment_address_format'];
                } else {
                    $format = '{firstname} {lastname}' . "\n" . '{company}' . "\n" . '{address_1}' . "\n" . '{address_2}' . "\n" . '{city} {postcode}' . "\n" . '{zone}' . "\n" . '{country}';
                }

                $find = array(
                    '{firstname}',
                    '{lastname}',
                    '{company}',
                    '{address_1}',
                    '{address_2}',
                    '{city}',
                    '{postcode}',
                    '{zone}',
                    '{zone_code}',
                    '{country}'
                );

                $replace = array(
                    'firstname' => $order_info['payment_firstname'],
                    'lastname'  => $order_info['payment_lastname'],
                    'company'   => $order_info['payment_company'],
                    'address_1' => $order_info['payment_address_1'],
                    'address_2' => $order_info['payment_address_2'],
                    'city'      => $order_info['payment_city'],
                    'postcode'  => $order_info['payment_postcode'],
                    'zone'      => $order_info['payment_zone'],
                    'zone_code' => $order_info['payment_zone_code'],
                    'country'   => $order_info['payment_country']
                );

                $data['payment_address'] = str_replace(array("\r\n", "\r", "\n"), '<br />', preg_replace(array("/\s\s+/", "/\r\r+/", "/\n\n+/"), '<br />', trim(str_replace($find, $replace, $format))));

                if ($order_info['shipping_address_format']) {
                    $format = $order_info['shipping_address_format'];
                } else {
                    $format = '{firstname} {lastname}' . "\n" . '{company}' . "\n" . '{address_1}' . "\n" . '{address_2}' . "\n" . '{city} {postcode}' . "\n" . '{zone}' . "\n" . '{country}';
                }

                $find = array(
                    '{firstname}',
                    '{lastname}',
                    '{company}',
                    '{address_1}',
                    '{address_2}',
                    '{city}',
                    '{postcode}',
                    '{zone}',
                    '{zone_code}',
                    '{country}'
                );

                $replace = array(
                    'firstname' => $order_info['shipping_firstname'],
                    'lastname'  => $order_info['shipping_lastname'],
                    'company'   => $order_info['shipping_company'],
                    'address_1' => $order_info['shipping_address_1'],
                    'address_2' => $order_info['shipping_address_2'],
                    'city'      => $order_info['shipping_city'],
                    'postcode'  => $order_info['shipping_postcode'],
                    'zone'      => $order_info['shipping_zone'],
                    'zone_code' => $order_info['shipping_zone_code'],
                    'country'   => $order_info['shipping_country']
                );

                $data['shipping_address'] = str_replace(array("\r\n", "\r", "\n"), '<br />', preg_replace(array("/\s\s+/", "/\r\r+/", "/\n\n+/"), '<br />', trim(str_replace($find, $replace, $format))));


                // Products
                $data['products'] = array();
                $data['vouchers'] = array();

                foreach ($product_query->rows as $product) {
                    $option_data = array();

                    $order_option_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "order_option WHERE order_id = '" . (int)$order_id . "' AND order_product_id = '" . (int)$product['order_product_id'] . "'");

                    foreach ($order_option_query->rows as $option) {
                        $value = $option['value'];

                        $option_data[] = array(
                            'name'  => $option['name'],
                            'value' => (utf8_strlen($value) > 20 ? utf8_substr($value, 0, 20) . '..' : $value)
                        );
                    }

                    $data['products'][] = array(
                        'name'     => $product['name'],
                        'model'    => $product['model'],
                        'option'   => $option_data,
                        'quantity' => $product['quantity'],
                        'price'    => $this->currency->format($product['price'] + ($this->config->get('config_tax') ? $product['tax'] : 0), $order_info['currency_code'], $order_info['currency_value']),
                        'total'    => $this->currency->format($product['total'] + ($this->config->get('config_tax') ? ($product['tax'] * $product['quantity']) : 0), $order_info['currency_code'], $order_info['currency_value'])
                    );
                }



                // Order Totals
                $data['totals'] = array();

                $order_total_query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "order_total` WHERE order_id = '" . (int)$order_id . "' ORDER BY sort_order ASC");

                foreach ($order_total_query->rows as $total) {
                    $data['totals'][] = array(
                        'title' => $total['title'],
                        'text'  => $this->currency->format($total['value'], $order_info['currency_code'], $order_info['currency_value']),
                    );
                }

                // Text Mail
                $text  = sprintf($language->get('text_new_greeting'), html_entity_decode($order_info['store_name'], ENT_QUOTES, 'UTF-8')) . "\n\n";
                $text .= $language->get('text_new_order_id') . ' ' . $order_id . "\n";
                $text .= $language->get('text_new_date_added') . ' ' . date($language->get('date_format_short'), strtotime($order_info['date_added'])) . "\n";
                $text .= $language->get('text_new_order_status') . ' ' . $order_status . "\n\n";

                if ($comment && $notify) {
                    $text .= $language->get('text_new_instruction') . "\n\n";
                    $text .= $comment . "\n\n";
                }

                // Products
                $text .= $language->get('text_new_products') . "\n";

                foreach ($product_query->rows as $product) {
                    $text .= $product['quantity'] . 'x ' . $product['name'] . ' (' . $product['model'] . ') ' . html_entity_decode($this->currency->format($product['total'] + ($this->config->get('config_tax') ? ($product['tax'] * $product['quantity']) : 0), $order_info['currency_code'], $order_info['currency_value']), ENT_NOQUOTES, 'UTF-8') . "\n";

                    $order_option_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "order_option WHERE order_id = '" . (int)$order_id . "' AND order_product_id = '" . $product['order_product_id'] . "'");

                    foreach ($order_option_query->rows as $option) {
                        $value = $option['value'];

                        $text .= chr(9) . '-' . $option['name'] . ' ' . (utf8_strlen($value) > 20 ? utf8_substr($value, 0, 20) . '..' : $value) . "\n";
                    }
                }


                $text .= "\n";

                $text .= $language->get('text_new_order_total') . "\n";

                foreach ($order_total_query->rows as $total) {
                    $text .= $total['title'] . ': ' . html_entity_decode($this->currency->format($total['value'], $order_info['currency_code'], $order_info['currency_value']), ENT_NOQUOTES, 'UTF-8') . "\n";
                }

                $text .= "\n";

                if ($order_info['customer_id']) {
                    $text .= $language->get('text_new_link') . "\n";
                    $text .= $order_info['store_url'] . 'index.php?route=account/order/info&order_id=' . $order_id . "\n\n";
                }

                // Comment
                if ($order_info['comment']) {
                    $text .= $language->get('text_new_comment') . "\n\n";
                    $text .= $order_info['comment'] . "\n\n";
                }
                $text .= $language->get('text_new_footer') . "\n\n";

                $mail = new Mail();
                $mail->protocol = $this->config->get('config_mail_protocol');
                $mail->parameter = $this->config->get('config_mail_parameter');
                $mail->smtp_hostname = $this->config->get('config_mail_smtp_hostname');
                $mail->smtp_username = $this->config->get('config_mail_smtp_username');
                $mail->smtp_password = html_entity_decode($this->config->get('config_mail_smtp_password'), ENT_QUOTES, 'UTF-8');
                $mail->smtp_port = $this->config->get('config_mail_smtp_port');
                $mail->smtp_timeout = $this->config->get('config_mail_smtp_timeout');

                $mail->setTo($order_info['email']);
                $mail->setFrom($this->config->get('config_email'));
                $mail->setSender(html_entity_decode($order_info['store_name'], ENT_QUOTES, 'UTF-8'));
                $mail->setSubject(html_entity_decode($subject, ENT_QUOTES, 'UTF-8'));
                //$mail->setHtml($this->load->view('mail/order.tpl', $data));
                $mail->setText($text);
                $mail->send();

                // Admin Alert Mail
                if ($this->config->get('config_order_mail')) {
                    $subject = sprintf($language->get('text_new_subject'), html_entity_decode($this->config->get('config_name'), ENT_QUOTES, 'UTF-8'), $order_id);

                    // HTML Mail
                    $data['text_greeting'] = $language->get('text_new_received');

                    if ($comment) {
                        if ($order_info['comment']) {
                            $data['comment'] = nl2br($comment) . '<br/><br/>' . $order_info['comment'];
                        } else {
                            $data['comment'] = nl2br($comment);
                        }
                    } else {
                        if ($order_info['comment']) {
                            $data['comment'] = $order_info['comment'];
                        } else {
                            $data['comment'] = '';
                        }
                    }

                    $data['text_download'] = '';

                    $data['text_footer'] = '';

                    $data['text_link'] = '';
                    $data['link'] = '';
                    $data['download'] = '';

                    // Text
                    $text  = $language->get('text_new_received') . "\n\n";
                    $text .= $language->get('text_new_order_id') . ' ' . $order_id . "\n";
                    $text .= $language->get('text_new_date_added') . ' ' . date($language->get('date_format_short'), strtotime($order_info['date_added'])) . "\n";
                    $text .= $language->get('text_new_order_status') . ' ' . $order_status . "\n\n";
                    $text .= $language->get('text_new_products') . "\n";

                    foreach ($product_query->rows as $product) {
                        $text .= $product['quantity'] . 'x ' . $product['name'] . ' (' . $product['model'] . ') ' . html_entity_decode($this->currency->format($product['total'] + ($this->config->get('config_tax') ? ($product['tax'] * $product['quantity']) : 0), $order_info['currency_code'], $order_info['currency_value']), ENT_NOQUOTES, 'UTF-8') . "\n";

                        $order_option_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "order_option WHERE order_id = '" . (int)$order_id . "' AND order_product_id = '" . $product['order_product_id'] . "'");

                        foreach ($order_option_query->rows as $option) {
                            if ($option['type'] != 'file') {
                                $value = $option['value'];
                            } else {
                                $value = utf8_substr($option['value'], 0, utf8_strrpos($option['value'], '.'));
                            }

                            $text .= chr(9) . '-' . $option['name'] . ' ' . (utf8_strlen($value) > 20 ? utf8_substr($value, 0, 20) . '..' : $value) . "\n";
                        }
                    }

                    foreach ($order_voucher_query->rows as $voucher) {
                        $text .= '1x ' . $voucher['description'] . ' ' . $this->currency->format($voucher['amount'], $order_info['currency_code'], $order_info['currency_value']);
                    }

                    $text .= "\n";

                    $text .= $language->get('text_new_order_total') . "\n";

                    foreach ($order_total_query->rows as $total) {
                        $text .= $total['title'] . ': ' . html_entity_decode($this->currency->format($total['value'], $order_info['currency_code'], $order_info['currency_value']), ENT_NOQUOTES, 'UTF-8') . "\n";
                    }

                    $text .= "\n";

                    if ($order_info['comment']) {
                        $text .= $language->get('text_new_comment') . "\n\n";
                        $text .= $order_info['comment'] . "\n\n";
                    }

                    $mail = new Mail();
                    $mail->protocol = $this->config->get('config_mail_protocol');
                    $mail->parameter = $this->config->get('config_mail_parameter');
                    $mail->smtp_hostname = $this->config->get('config_mail_smtp_hostname');
                    $mail->smtp_username = $this->config->get('config_mail_smtp_username');
                    $mail->smtp_password = html_entity_decode($this->config->get('config_mail_smtp_password'), ENT_QUOTES, 'UTF-8');
                    $mail->smtp_port = $this->config->get('config_mail_smtp_port');
                    $mail->smtp_timeout = $this->config->get('config_mail_smtp_timeout');

                    $mail->setTo($this->config->get('config_email'));
                    $mail->setFrom($this->config->get('config_email'));
                    $mail->setSender(html_entity_decode($order_info['store_name'], ENT_QUOTES, 'UTF-8'));
                    $mail->setSubject(html_entity_decode($subject, ENT_QUOTES, 'UTF-8'));
                    //$mail->setHtml($this->load->view('mail/order.tpl', $data));
                    $mail->setText($text);
                    $mail->send();

                    // Send to additional alert emails
                    $emails = explode(',', $this->config->get('config_mail_alert'));
                    foreach ($emails as $email) {
                        if ($email && filter_var($email, FILTER_VALIDATE_EMAIL)) {
                            $mail->setTo($email);
                            $mail->send();
                        }
                    }
                }
            }
        }
    }
    public function getOrderStatusIdByName($name)
    {
        $sql ="SELECT `order_status_id` FROM `".DB_PREFIX."order_status` WHERE `name`='".$name."'";
        $query=$this->db->query($sql);
        if($query && $query->num_rows)
            return $query->row['order_status_id'];
    }
    public function getOrder($order_id)
    {
        $order_query = $this->db->query("SELECT *, (SELECT CONCAT(c.firstname, ' ', c.lastname) FROM " . DB_PREFIX . "customer c WHERE c.customer_id = o.customer_id) AS customer FROM `" . DB_PREFIX . "order` o WHERE o.order_id = '" . (int)$order_id . "'");

        if ($order_query->num_rows) {
            $reward = 0;

            $order_product_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "order_product WHERE order_id = '" . (int)$order_id . "'");

            foreach ($order_product_query->rows as $product) {
                $reward += $product['reward'];
            }

            $country_query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "country` WHERE country_id = '" . (int)$order_query->row['payment_country_id'] . "'");

            if ($country_query->num_rows) {
                $payment_iso_code_2 = $country_query->row['iso_code_2'];
                $payment_iso_code_3 = $country_query->row['iso_code_3'];
            } else {
                $payment_iso_code_2 = '';
                $payment_iso_code_3 = '';
            }

            $zone_query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "zone` WHERE zone_id = '" . (int)$order_query->row['payment_zone_id'] . "'");

            if ($zone_query->num_rows) {
                $payment_zone_code = $zone_query->row['code'];
            } else {
                $payment_zone_code = '';
            }

            $country_query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "country` WHERE country_id = '" . (int)$order_query->row['shipping_country_id'] . "'");

            if ($country_query->num_rows) {
                $shipping_iso_code_2 = $country_query->row['iso_code_2'];
                $shipping_iso_code_3 = $country_query->row['iso_code_3'];
            } else {
                $shipping_iso_code_2 = '';
                $shipping_iso_code_3 = '';
            }

            $zone_query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "zone` WHERE zone_id = '" . (int)$order_query->row['shipping_zone_id'] . "'");

            if ($zone_query->num_rows) {
                $shipping_zone_code = $zone_query->row['code'];
            } else {
                $shipping_zone_code = '';
            }

            if ($order_query->row['affiliate_id']) {
                $affiliate_id = $order_query->row['affiliate_id'];
            } else {
                $affiliate_id = 0;
            }

            $affiliate_firstname = '';
            $affiliate_lastname = '';

            $language_code = '';
            $language_filename = '';
            $language_directory = '';

            return array(
                'order_id'                => $order_query->row['order_id'],
                'invoice_no'              => $order_query->row['invoice_no'],
                'invoice_prefix'          => $order_query->row['invoice_prefix'],
                'store_id'                => $order_query->row['store_id'],
                'store_name'              => $order_query->row['store_name'],
                'store_url'               => $order_query->row['store_url'],
                'customer_id'             => $order_query->row['customer_id'],
                'customer'                => $order_query->row['customer'],
                'customer_group_id'       => $order_query->row['customer_group_id'],
                'firstname'               => $order_query->row['firstname'],
                'lastname'                => $order_query->row['lastname'],
                'email'                   => $order_query->row['email'],
                'telephone'               => $order_query->row['telephone'],
                'fax'                     => $order_query->row['fax'],
                'custom_field'            => unserialize($order_query->row['custom_field']),
                'payment_firstname'       => $order_query->row['payment_firstname'],
                'payment_lastname'        => $order_query->row['payment_lastname'],
                'payment_company'         => $order_query->row['payment_company'],
                'payment_address_1'       => $order_query->row['payment_address_1'],
                'payment_address_2'       => $order_query->row['payment_address_2'],
                'payment_postcode'        => $order_query->row['payment_postcode'],
                'payment_city'            => $order_query->row['payment_city'],
                'payment_zone_id'         => $order_query->row['payment_zone_id'],
                'payment_zone'            => $order_query->row['payment_zone'],
                'payment_zone_code'       => $payment_zone_code,
                'payment_country_id'      => $order_query->row['payment_country_id'],
                'payment_country'         => $order_query->row['payment_country'],
                'payment_iso_code_2'      => $payment_iso_code_2,
                'payment_iso_code_3'      => $payment_iso_code_3,
                'payment_address_format'  => $order_query->row['payment_address_format'],
                'payment_custom_field'    => unserialize($order_query->row['payment_custom_field']),
                'payment_method'          => $order_query->row['payment_method'],
                'payment_code'            => $order_query->row['payment_code'],
                'shipping_firstname'      => $order_query->row['shipping_firstname'],
                'shipping_lastname'       => $order_query->row['shipping_lastname'],
                'shipping_company'        => $order_query->row['shipping_company'],
                'shipping_address_1'      => $order_query->row['shipping_address_1'],
                'shipping_address_2'      => $order_query->row['shipping_address_2'],
                'shipping_postcode'       => $order_query->row['shipping_postcode'],
                'shipping_city'           => $order_query->row['shipping_city'],
                'shipping_zone_id'        => $order_query->row['shipping_zone_id'],
                'shipping_zone'           => $order_query->row['shipping_zone'],
                'shipping_zone_code'      => $shipping_zone_code,
                'shipping_country_id'     => $order_query->row['shipping_country_id'],
                'shipping_country'        => $order_query->row['shipping_country'],
                'shipping_iso_code_2'     => $shipping_iso_code_2,
                'shipping_iso_code_3'     => $shipping_iso_code_3,
                'shipping_address_format' => $order_query->row['shipping_address_format'],
                'shipping_custom_field'   => unserialize($order_query->row['shipping_custom_field']),
                'shipping_method'         => $order_query->row['shipping_method'],
                'shipping_code'           => $order_query->row['shipping_code'],
                'comment'                 => $order_query->row['comment'],
                'total'                   => $order_query->row['total'],
                'reward'                  => $reward,
                'order_status_id'         => $order_query->row['order_status_id'],
                'affiliate_id'            => $order_query->row['affiliate_id'],
                'affiliate_firstname'     => $affiliate_firstname,
                'affiliate_lastname'      => $affiliate_lastname,
                'commission'              => $order_query->row['commission'],
                'language_id'             => $order_query->row['language_id'],
                'language_code'           => $language_code,
                'language_filename'       => $language_filename,
                'language_directory'      => $language_directory,
                'currency_id'             => $order_query->row['currency_id'],
                'currency_code'           => $order_query->row['currency_code'],
                'currency_value'          => $order_query->row['currency_value'],
                'ip'                      => $order_query->row['ip'],
                'forwarded_ip'            => $order_query->row['forwarded_ip'],
                'user_agent'              => $order_query->row['user_agent'],
                'accept_language'         => $order_query->row['accept_language'],
                'date_added'              => $order_query->row['date_added'],
                'date_modified'           => $order_query->row['date_modified']
            );
        } else {
            return;
        }
    }
}