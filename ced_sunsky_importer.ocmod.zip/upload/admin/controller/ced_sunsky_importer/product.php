<?php

class ControllerCedSunskyImporterProduct extends Controller
{
	private $error = array();

    public function index()
    {
        $data = $this->load->language('ced_sunsky_importer/product');
        //$this->load->model('ced_sunsky_importer/setting');

        $this->document->setTitle($this->language->get('heading_title'));

        $data['heading_title'] = $this->language->get('heading_title');
        //entry
        $data['entry_url'] = $this->language->get('entry_url');
        
        //text
        $data['text_disabled'] = $this->language->get('text_disabled');
        $data['text_enabled'] = $this->language->get('text_enabled');

        //buttons texts
        $data['button_save'] = $this->language->get('button_save');
        $data['button_cancel'] = $this->language->get('button_cancel');
        $data['button_import'] = $this->language->get('button_import');

        //breadcrumbs
        $data['breadcrumbs'] = array();
        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/home', 'user_token=' . $this->session->data['user_token'], 'SSL')
        );
        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_extension'),
            'href' => $this->url->link('extension/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module', 'SSL')
        );

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('heading_title'),
            'href' => $this->url->link('ced_sunsky_importer/product', 'user_token=' . $this->session->data['user_token'] . '&type=module', 'SSL')
        );

        $data['action'] = $this->url->link('ced_sunsky_importer', 'user_token=' . $this->session->data['user_token'], 'SSL');

        // $data['fetchProduct'] = $this->url->link('ced_sunsky_importer/product/fetchProduct', 'user_token=' . $this->session->data['user_token'], 'SSL');
        $data['user_token'] = $this->session->data['user_token'];

        $opc_error = array(
            'warning',
            'filter'
        );

        foreach ($opc_error as $key => $value) {
            if (isset($this->error[$value])) {
                $data['error_' . $value] = $this->error[$value];
            } else {
                $data['error_' . $value] = '';
            }
        }

        // Categories
        $this->load->model('catalog/category');

        $categories = $this->model_catalog_category->getCategories();

        if(isset($categories) && !empty($categories))
        {
        	$data['product_categories'] = $categories;
        	// foreach ($categories as $key => $category_info) {
	        //     if ($category_info) {
	        //         $data['product_categories'][] = array(
	        //             'category_id' => $category_info['category_id'],
	        //             'name' => $category_info['name']
	        //         );
	        //     }
	        // }
        } else {
        	$data['product_categories'] = array();
        }

        // Manufacturer
        $this->load->model('catalog/manufacturer');

        $manufacturer = $this->model_catalog_manufacturer->getManufacturers();

        if(isset($manufacturer) && !empty($manufacturer))
        	$data['product_manufacturer'] = $manufacturer;
        else
        	$data['product_manufacturer'] = array();
        
        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');
        $this->response->setOutput($this->load->view('ced_sunsky_importer/product_importer', $data));
    }

    public function importProduct()
    {
    	$post_data = $this->request->post;

        $category_id = !empty($post_data['category_id']) ? $post_data['category_id'] : '';
        $manufacturer_id = !empty($post_data['manufacturer_id']) ? $post_data['manufacturer_id'] : '';

    	$response['success'] = false;
        $response['message'] = 'Product not imported';
        $intialProdData = [];
        try {
            $this->load->library('cedsunskyimporter');
            $cedsunskyimporter = Cedsunskyimporter::getInstance($this->registry);
            $this->load->model('setting/setting');
            $cedsunskyConfigData = $this->model_setting_setting->getSetting('ced_sunsky_importer');

            if(isset($post_data['import_basis']) && ($post_data['import_basis'] == '1'))
            {
                $url = 'category!getChildren.do';
                $params = array(
                    'parentId' => !empty($post_data['parentId']) ? $post_data['parentId'] : '',
                    'gmtModifiedStart' => !empty($post_data['category_gmtModifiedStart']) ? $post_data['category_gmtModifiedStart'] : ''
                );
                $productData = $cedsunskyimporter->getProductData($url, $params);
            } elseif(isset($post_data['import_basis']) && ($post_data['import_basis'] == '2')) {
                $url = 'product!search.do';
                $params = array(
                    'categoryId' => !empty($post_data['categoryId']) ? $post_data['categoryId'] : '',
                    'gmtModifiedStart' => !empty($post_data['product_gmtModifiedStart']) ? $post_data['product_gmtModifiedStart'] : '',
                    'status' => !empty($post_data['status']) ? $post_data['status'] : '',
                    'brandName' => !empty($post_data['brandName']) ? $post_data['brandName'] : '',
                    'pageSize' => '100'
                );
                $productData = $cedsunskyimporter->getProductData($url, $params);
            } else {
                $url = 'product!detail.do';
                $params = array('itemNo' => $post_data['itemNo']);
                $productData = $cedsunskyimporter->getProductData($url, $params);

            }
            
            if(isset($productData['success']) && ($productData['success'] == true))
            {
                if(!isset($productData['message']['result']['0'])){
                    $productDatum = array();
                    $productData['0'] = $productData['message'];
                } else {
                    $productDatum = $productData['message']['result'];
                }
                //echo '<pre>'; print_r($productDatum); die;
                $response = $cedsunskyimporter->prepareProductData($cedsunskyConfigData, $productDatum, $category_id, $manufacturer_id);
            } else {
                $response = $productData;
            }
        } catch (\Exception $exception) {
            $response['success'] = false;
            $response['message'] = $exception->getMessage();
        }
        $this->response->setOutput(json_encode($response));
    }
}