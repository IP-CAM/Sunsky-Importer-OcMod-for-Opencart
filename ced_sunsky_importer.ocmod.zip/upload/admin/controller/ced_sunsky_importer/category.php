<?php

class ControllerCedSunskyImporterCategory extends Controller
{
    private $error = array();

    public function index()
    {
        $data = $this->load->language('ced_sunsky_importer/category');
        //$this->load->model('ced_sunsky_importer/setting');

        $this->document->setTitle($this->language->get('heading_title'));

        $data['heading_title'] = $this->language->get('heading_title');
        //entry
        $data['entry_url'] = $this->language->get('entry_url');

        //text
        $data['text_disabled'] = $this->language->get('text_disabled');
        $data['text_enabled'] = $this->language->get('text_enabled');

        //buttons texts
        $data['button_save'] = $this->language->get('button_save');
        $data['button_cancel'] = $this->language->get('button_cancel');
        $data['button_import'] = $this->language->get('button_import');

        //breadcrumbs
        $data['breadcrumbs'] = array();
        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/home', 'user_token=' . $this->session->data['user_token'], 'SSL')
        );
        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_extension'),
            'href' => $this->url->link('extension/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module', 'SSL')
        );

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('heading_title'),
            'href' => $this->url->link('ced_sunsky_importer/category', 'user_token=' . $this->session->data['user_token'] . '&type=module', 'SSL')
        );

        $data['action'] = $this->url->link('ced_sunsky_importer', 'user_token=' . $this->session->data['user_token'], 'SSL');

        $data['user_token'] = $this->session->data['user_token'];

        $opc_error = array(
            'warning',
            'filter'
        );

        foreach ($opc_error as $key => $value) {
            if (isset($this->error[$value])) {
                $data['error_' . $value] = $this->error[$value];
            } else {
                $data['error_' . $value] = '';
            }
        }

        if (isset($this->request->get['filter_id'])) {
            $filter_id = $this->request->get['filter_id'];
        } else {
            $filter_id = null;
        }

        if (isset($this->request->get['filter_name'])) {
            $filter_name = $this->request->get['filter_name'];
        } else {
            $filter_name = null;
        }

        if(isset($this->request->get['sort'])){
            $sort = $this->request->get['sort'];
        } else {
            $sort = 'name';
        }

        if(isset($this->request->get['order'])){
            $order = $this->request->get['order'];
        } else {
            $order = 'ASC';
        }

        if(isset($this->request->get['page'])){
            $page = $this->request->get['page'];
        } else {
            $page = '1';
        }

        $url = '';

        if (isset($this->request->get['filter_id'])) {
            $url .= '&filter_id=' . urlencode(html_entity_decode($this->request->get['filter_id'], ENT_QUOTES, 'UTF-8'));
        }

        if (isset($this->request->get['filter_name'])) {
            $url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
        }

        if(isset($this->request->get['sort'])){
            $url .= '&sort=' . $this->request->get['sort'];
        }

        if(isset($this->request->get['order'])){
            $url .= '&order=' . $this->request->get['order'];
        }

        if(isset($this->request->get['page'])){
            $url .= '&page=' . $this->request->get['page'];
        }

        $data['cedsunsky_category'] = array();

        $filter_array = array(
            'filter_id'	   => $filter_id,
            'filter_name'  => $filter_name,
            'sort'  => $sort,
            'order' => $order,
            'start' => ($page - 1) * $this->config->get('config_limit_admin'),
            'limit' => $this->config->get('config_limit_admin')
        );

        $this->load->model('ced_sunsky_importer/category');

        $cedsunsky_total_category = $this->model_ced_sunsky_importer_category->getTotalCedsunskyCategory($filter_array);

        $results = $this->model_ced_sunsky_importer_category->getCedsunskyCategory($filter_array);

        foreach($results as $result){
            $data['cedsunsky_category'][]  =  array(
                'category_id'      => $result['category_id'],
                'name'             => $result['name']
                // 'sort_order'       => $result['sort_order']
            );
        }

        $data['text_list'] = $this->language->get('text_list');
        $data['text_no_results'] = $this->language->get('text_no_results');

        $data['column_category_id'] = $this->language->get('column_category_id');
        $data['column_name'] = $this->language->get('column_name');

        $data['entry_id'] = $this->language->get('entry_id');
        $data['entry_name'] = $this->language->get('entry_name');

        $data['button_filter'] = $this->language->get('button_filter');

        if(isset($this->request->post['selected'])) {
            $data['selected'] = (array)$this->request->post['selected'];
        } else {
            $data['selected'] = array();
        }

        $url = '';

        if (isset($this->request->get['filter_id'])) {
            $url .= '&filter_id=' . urlencode(html_entity_decode($this->request->get['filter_id'], ENT_QUOTES, 'UTF-8'));
        }

        if (isset($this->request->get['filter_name'])) {
            $url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
        }

        if($order == 'ASC'){
            $url .= '&order=DESC';
        } else {
            $url .= '&order=ASC';
        }

        if(isset($this->request->get['page'])) {
            $url .= '&page=' . $this->request->get['page'];
        }

        $data['sort_category_id'] = $this->url->link('ced_sunsky_importer/category', 'user_token=' . $this->session->data['user_token'] . '&sort=category_id' . $url, 'SSl');
        $data['sort_name'] = $this->url->link('ced_sunsky_importer/category', 'user_token=' . $this->session->data['user_token'] . '&sort=cf.name' . $url, 'SSl');

        $url = '';

        if (isset($this->request->get['filter_id'])) {
            $url .= '&filter_id=' . urlencode(html_entity_decode($this->request->get['filter_id'], ENT_QUOTES, 'UTF-8'));
        }

        if (isset($this->request->get['filter_name'])) {
            $url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
        }

        if(isset($this->request->get['sort'])) {
            $url .= '&sort=' . $this->request->get['sort'];
        }

        if(isset($this->request->get['order'])) {
            $url .= '&order=' . $this->request->get['order'];
        }

        $pagination = new Pagination();
        $pagination->total = $cedsunsky_total_category;
        $pagination->page  = $page;
        $pagination->limit = $this->config->get('config_limit_admin');
        $pagination->url   = $this->url->link('ced_sunsky_importer/category', 'user_token=' . $this->session->data['user_token'] . $url . '&page={page}', 'SSl');

        $data['pagination'] = $pagination->render();

        $data['results'] = sprintf($this->language->get('text_pagination'), ($cedsunsky_total_category) ? (($page - 1) * $this->config->get('config_limit_admin')) + 1 : 0, ((($page - 1) * $this->config->get('config_limit_admin')) > ($cedsunsky_total_category - $this->config->get('config_limit_admin'))) ? $cedsunsky_total_category : ((($page - 1) * $this->config->get('config_limit_admin')) + $this->config->get('config_limit_admin')) , $cedsunsky_total_category, ceil($cedsunsky_total_category / $this->config->get('config_limit_admin')));

        $data['filter_id'] = $filter_id;
        $data['filter_name'] = $filter_name;

        $data['sort'] = $sort;
        $data['order'] = $order;

        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');
        $this->response->setOutput($this->load->view('ced_sunsky_importer/category_importer', $data));
    }

    public function autocomplete() {
        $json = array();

        if (isset($this->request->get['filter_name'])) {
            $this->load->model('ced_sunsky_importer/category');

            $filter_data = array(
                'filter_name' => $this->request->get['filter_name'],
                'start'       => 0,
                'limit'       => 5
            );

            $results = $this->model_ced_sunsky_importer_category->getCedsunskyCategory($filter_data);

            foreach ($results as $result) {
                $json[] = array(
                    'category_id'    => $result['category_id'],
                    'name'            => strip_tags(html_entity_decode($result['name'], ENT_QUOTES, 'UTF-8')),
                );
            }
        }

        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }

    public function importCategory()
    {
        $post_data = $this->request->post;

        $response['success'] = false;
        $response['message'] = 'Category not imported';
        $intialProdData = [];
        try {
            $url = 'category!getChildren.do';
            $params = array(
                'parentId' => !empty($post_data['parentId']) ? $post_data['parentId'] : '',
                'gmtModifiedStart' => !empty($post_data['gmtModifiedStart']) ? $post_data['gmtModifiedStart'] : ''
            );
            $this->load->library('cedsunskyimporter');
            $cedsunskyimporter = Cedsunskyimporter::getInstance($this->registry);
            $categoryData = $cedsunskyimporter->getSunskyData($url, $params);
            //echo '<pre>'; print_r($categoryData); die;

            if(isset($categoryData['success']) && ($categoryData['success'] == true))
            {
                if(!isset($categoryData['message']['0'])){
                    $categoryDatum = array();
                    $categoryDatum['0'] = $categoryData['message'];
                } else {
                    $categoryDatum = $categoryData['message'];
                }
                //echo '<pre>'; print_r($categoryDatum); die;
                $this->load->model('ced_sunsky_importer/category');
                $response = $this->model_ced_sunsky_importer_category->addCategories($categoryDatum);
            } else {
                $response = $categoryData;
            }
        } catch (\Exception $exception) {
            $response['success'] = false;
            $response['message'] = $exception->getMessage();
        }
        $this->response->setOutput(json_encode($response));
    }

}