<?php
class ControllerCedSunskyImporterColumnLeft extends Controller {
	public function eventMenu($route, &$data) 
	{
		$this->load->language('extension/module/ced_sunsky_importer');
				
		// Sunsky menues
		$sunsky_menu=array();

		// Sunsky Product
		if ($this->user->hasPermission('access', 'ced_sunsky_importer/product')) {
			$sunsky_menu[] = array(
				'name'	   => $this->language->get('text_product'),
				'href'     => $this->url->link('ced_sunsky_importer/product', 'user_token=' . $this->session->data['user_token'], true),
				'children' => array()
			);
		}

		// Sunsky Order
		if ($this->user->hasPermission('access', 'ced_sunsky_importer/order')) {
			$sunsky_menu[] = array(
				'name'	   => $this->language->get('text_order'),
				'href'     => $this->url->link('ced_sunsky_importer/order', 'user_token=' . $this->session->data['user_token'], true),
				'children' => array()
			);
		}

		// Sunsky Order
		if ($this->user->hasPermission('access', 'ced_sunsky_importer/order/rejected')) {
			$sunsky_menu[] = array(
				'name'	   => $this->language->get('text_order_error'),
				'href'     => $this->url->link('ced_sunsky_importer/order/rejected', 'user_token=' . $this->session->data['user_token'], true),
				'children' => array()
			);
		}

		// Sunsky Configuration	
		$sunsky_menu[] = array(
			'name'	   => $this->language->get('text_configuration'),
			'href'     => $this->url->link('extension/module/ced_sunsky_importer', 'user_token=' . $this->session->data['user_token'], true),
			'children' => array()
		);

		$data['menus'][] = array(
		'id'       => 'menu-sunsky',
		'icon'	   => 'fa-rocket',
		'name'	   => $this->language->get('text_sunsky'),
		'href'     => '',
		'children' => $sunsky_menu
		);
				
	}
}
