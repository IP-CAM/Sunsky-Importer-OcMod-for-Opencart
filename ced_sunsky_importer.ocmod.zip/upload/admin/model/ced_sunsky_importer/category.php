<?php

class ModelCedSunskyImporterCategory extends Model {

    public function getCedsunskyCategory($data = array()) {
        $sql = "SELECT * FROM " . DB_PREFIX . "ced_sunsky_importer_category WHERE category_id > '0'";

        if (!empty($data['filter_id'])) {
            $sql .= " AND category_id = '" . (int)$data['filter_id'] . "'";
        }

        if (!empty($data['filter_name'])) {
            $sql .= " AND name LIKE '%" . html_entity_decode($data['filter_name']) . "%'";
        }

        $sql .= " GROUP BY category_id";

        $sort_data = array(
            'name',
            'category_id'
        );

        if (isset($data['sort']) && in_array($data['sort'], $sort_data)) {
            $sql .= " ORDER BY " . $data['sort'];
        } else {
            $sql .= " ORDER BY category_id";
        }

        if (isset($data['order']) && ($data['order'] == 'DESC')) {
            $sql .= " DESC";
        } else {
            $sql .= " ASC";
        }

        if (isset($data['start']) || isset($data['limit'])) {
            if ($data['start'] < 0) {
                $data['start'] = 0;
            }

            if ($data['limit'] < 1) {
                $data['limit'] = 20;
            }

            $sql .= " LIMIT " . (int)$data['start'] . "," . (int)$data['limit'];
        }

        $query = $this->db->query($sql);

        return $query->rows;
    }

    public function getTotalCedsunskyCategory($data = array()) {

        $sql = " SELECT COUNT(DISTINCT category_id) AS total FROM " . DB_PREFIX . "ced_sunsky_importer_category WHERE category_id > '0' ";

        if (!empty($data['filter_id'])) {
            $sql .= " AND category_id = '" . (int)$data['filter_id'] . "'";
        }

        if (!empty($data['filter_name'])) {
            $sql .= " AND name LIKE '%" . html_entity_decode($data['filter_name']) . "%'";
        }

        $query = $this->db->query($sql);

        return $query->row['total'];
    }

    public function addCategories($category_data = array())
    {
        $response = array();
        if(isset($category_data) && !empty($category_data) && is_array($category_data))
        {
            try
            {
                foreach($category_data as $key => $category)
                {
                    $categoryExist = $this->db->query("SELECT * FROM `". DB_PREFIX ."ced_sunsky_importer_category` WHERE `category_id` = '". (int) $category['id'] ."' ");
                    //echo '<pre>'; print_r($categoryExist->row); die;
                    if($categoryExist->num_rows)
                    {
                        $this->db->query("UPDATE `". DB_PREFIX ."ced_sunsky_importer_category` SET
                         `name` = '". $this->db->escape($category['name']) ."',
                         `status` = '". (int) $category['status'] ."',
                         `parentId` = '". (int) $category['parentId'] ."',
                         `gmtModified` = '".  $category['gmtModified'] ."',
                         `hsCode` = '". (int) $category['hsCode'] ."',
                         `code` = '". (int) $category['code'] ."'
                          WHERE `category_id` = '". (int) $category['id'] ."'
                         ");
                    } else {
                        $this->db->query("INSERT INTO `". DB_PREFIX ."ced_sunsky_importer_category` SET
                     `category_id` = '". (int) $category['id'] ."',
                     `name` = '". $this->db->escape($category['name']) ."',
                     `status` = '". (int) $category['status'] ."',
                     `parentId` = '". (int) $category['parentId'] ."',
                     `gmtModified` = '". $category['gmtModified'] ."',
                     `hsCode` = '". (int) $category['hsCode'] ."',
                     `code` = '". (int) $category['code'] ."'
                     ");
                    }
                }
                $response['success'] = true;
                $response['message'] = 'Categories Imported Successfully!';
            } catch(Exception $e)
            {
                $response['success'] = true;
                $response['message'] = $e->getMessage();
            }
        }
        return $response;
    }

}