<?php
// Heading
$_['heading_title'] = 'Sunsky Importer By Cedcommerce';

//tab
$_['tab_general'] = 'Setting';
$_['tab_default'] = 'Default Values';
$_['tab_mapping'] = 'Field Mapping';

//Text
$_['text_module'] = 'Modules';
$_['text_none'] = 'None';
$_['text_yes'] = 'Modules';
$_['text_extension'] = 'Extension';
$_['text_edit']= 'Edit Importer Configuration';
$_['text_success'] = 'Success: You have modified module Sunsky Importer!';

// Column Left
$_['text_sunsky'] = 'Ced Sunsky Importer';
$_['text_configuration'] = 'Configuration';
$_['text_product'] = 'Product Import';
$_['text_order'] = 'Order';
$_['text_order_error'] = 'Order Error';

//Entry
$_['entry_status'] = 'Status';
$_['entry_category'] = 'Default Category';
$_['entry_store'] = 'Store(s) In Created Product';
$_['entry_weight_class'] = 'Weight Class';
$_['entry_tax_class'] = 'Tax Class';
$_['entry_length_class'] = 'Length Class';
$_['entry_available_date'] = 'Available Date';

$_['entry_key'] = 'Key';
$_['entry_secret'] = 'Secret';
$_['entry_store'] = 'Default Store';
$_['entry_language'] = 'Store Language';

//Error
$_['error_permission'] = 'Warning: You do not have permission to modify module Sunsky Importer!';
$_['error_key'] = 'Key is Required.';
$_['error_secret'] = 'Secret is Required.';