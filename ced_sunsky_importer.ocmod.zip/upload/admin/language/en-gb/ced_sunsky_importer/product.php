<?php
// Heading
$_['heading_title'] = 'Import Sunsky Product(s)';

//Text
$_['text_module'] = 'Modules';
$_['text_edit']= 'Import Sunsky Product(s)';
$_['text_success'] = 'Success: You have modified module Sunsky Product(s) Importer!';

//Entry
$_['entry_category'] = 'Store Category';
$_['entry_manufacturer'] = 'Store Manufacturer';
$_['entry_parentId'] = 'Parent ID';
$_['entry_categoryId'] = 'Category ID';
$_['entry_gmtModifiedStart'] = 'Gmt Modified Start';
$_['entry_status'] = 'Product Status';
$_['entry_brandName'] = 'Brand Name';
$_['entry_import_basis'] = 'Import Product on the basis of';
$_['entry_itemNo'] = 'Item No.';

// Button
$_['button_import'] = 'Import';

//Error
$_['error_permission'] = 'Warning: You do not have permission to modify module Sunsky Importer!';